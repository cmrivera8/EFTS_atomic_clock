Informacj� o instalacji bibliotek znajdziesz pod adresem http://arduino.cc/en/Guide/Libraries
