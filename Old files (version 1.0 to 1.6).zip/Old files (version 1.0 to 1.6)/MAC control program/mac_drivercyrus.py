from adf4158 import *
import serial, time
from serial.tools import list_ports

class LaserCurrentSource(SubComponent):

	_current_word = 23657 # 0.92mA environ pour vixar

	def startup(self):
		print "0"
		self.parent.send("0")


	@property
	def current(s):
		return s._current_word/(2.**16)*2.5

	@current.setter
	def current(s,value):
		assert 0<=value and value<2
		s._current_word = int(value/2.5*(2.**16))
		print s._current_word
		s.parent.send("9 "+str(s._current_word))

class MagFieldCurrentSource(SubComponent):

	_current_word = 10000 # 1.7 mA

	@property
	def current(s):
		return s._current_word/(2.**16)*50.

	@current.setter
	def current(s,value):
		assert 0<=value and value<50
		s._current_word = int(value/50.*(2.**16))
		print s._current_word
		s.parent.send("8 "+str(s._current_word))

class LaserTECcontroller(SubComponent):

	_tec_volt_word = 8800
	_tec_state = False

	@property
	def tec_state(self):
		return self._tec_state

	@tec_state.setter
	def tec_state(self,state):
		_tec_state = bool(state)
		if _tec_state:
			print "TEC On"
			self.parent.send("6")
		else: 
			print "TEC Off"
			self.parent.send("7")

	@property
	def tec_volt_word(self):
		return self._tec_volt_word
	
	@tec_volt_word.setter
	def tec_volt_word(self,value):
		assert 1000<=value<=9800
		self._tec_volt_word = int(value)
		print self._tec_volt_word
		self.parent.send("5 "+str(self._tec_volt_word))

	@property
	def tec_resistance(self):
		return 10000.*(1./float(2**14/float(self._tec_volt_word)-1))
	
	@tec_resistance.setter
	def tec_resistance(self,resistance):
		self.tec_volt_word = int(2**14/(10000./float(resistance)+1))

class MAC(object):

	def __init__(self):
		self.waiting = False
		try:
			portserie = [port[0] for port in list_ports.comports()]
			self.ser = serial.Serial(port= portserie[-1], baudrate=115200, timeout=1)
			print "Using serial port %s; found %s" % (portserie[-1], portserie)
			print "using portserie:",(portserie[-1])        
		except serial.serialutil.SerialException:            
			print "no connected"
			self.ser = None
		else:
			pass

		self.adf = ADF4158(self)
		self.lascursour = LaserCurrentSource(self)
		self.magcursour = MagFieldCurrentSource(self)
		self.lastecctrl = LaserTECcontroller(self)

	def __del__(self):
		if self.ser:
			self.ser.close()

	def send(self, command):
		print "Sent: "+command
		if self.ser is not None: self.ser.write(command+"\r\n")
		else: print "Serial device not connected"

	def query(self, command):
		while self.waiting:
			pass
		self.waiting = True
		self.send(command)
		time.sleep(0.020)
		response = self.ser.readline()[:-2]
		self.waiting = False
		return response

	def startup(self):
		print "Start up sequence"
		self.send("2")

	def lock(self):
		print "Lock ON"
		self.send("3")
        
        
        
        
if __name__=='__main__':
	mac = MAC()        