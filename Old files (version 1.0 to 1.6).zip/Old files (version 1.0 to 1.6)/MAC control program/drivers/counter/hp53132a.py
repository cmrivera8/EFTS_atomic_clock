import visa, time
import threading
import Queue

class FreqFetcher(threading.Thread):

	# new_current_value = pg.QtCore.Signal()
	frequenciesQueue = Queue.Queue()

	def __init__(self,counter):
		super(FreqFetcher, self).__init__()
		self.running = False
		self.counter = counter

	def run(self):
		self.running = True
		while self.running:
			freq = self.counter.fetch()
			# print(freq)
			if self.counter.queue:
				# print(freq)
				self.counter.queue.put([time.time(),freq])

class HP53132A(object):

	fetcher = None
	queue = None
	header = ["Time","Frequency (Hz)"]

	def __init__(self,gpibAdress=25):
		gpibID = "GPIB::"+str(gpibAdress)+"::INSTR"
		rm = visa.ResourceManager()
		self.inst = rm.open_resource(gpibID,read_termination='\n')

	def query(self,request):
		self.inst.write(request)
		return self.inst.read()

	def getFunction(self):
		return self.query("FUNC?")

	def setFunction(self,function):
		self.inst.write("FUNC "+str(function))
		return

	def setConfig(self,delay=1):
		self.inst.write(":FORMAT ASCII")
		self.inst.write(":FUNC FREQ 1")
		self.inst.write(":FREQ:ARM:STAR:SOUR IMM")
		self.inst.write(":FREQ:ARM:STOP:SOUR TIM")
		self.inst.write(":FREQ:ARM:STOP:TIM 1")
		self.inst.write(':ROSC:SOUR EXT')
		self.inst.write(':ROSC:EXT:CHECK OFF')
		self.inst.write(":EVENT1:LEVEL 0")
		self.inst.write(":DIAG:CAL:INT:AUTO OFF")
		self.inst.write(":DISP:ENABLE OFF")
		self.inst.write(":HCOPY:CONT OFF")
		self.inst.write(":CALC:MATH:STATE OFF")
		self.inst.write(":CALC2:LIM:STATE OFF")
		self.inst.write(":CALC3:AVER:STATE OFF")
		self.inst.write("*DDT #15 FETC?")
		self.inst.write(":INIT:CONT ON")
		self.inst.write("FETCH:FREQ?")
		freq = float(self.inst.read())
		self.inst.write("FETCH:EXP1 "+str(freq))

		#request = ":func 'freq 1';:freq:arm:star:sour imm;:freq:arm:stop:sour tim;:freq:arm:stop:tim "+str(delay)
		#self.inst.write(request)
		return
	
	def getFrequency(self):
		return float(self.query("READ:FREQ?"))
	
	def fetch(self):
		return float(self.query("FETC?"))

	def startFetcher(self):
		self.setConfig()
		self.fetcher = FreqFetcher(self)
		self.fetcher.start()

	def stopFetcher(self,block=True):
		self.fetcher.running = False
		if block: self.fetcher.join()

if __name__=='__main__':
	counter = HP53132A()