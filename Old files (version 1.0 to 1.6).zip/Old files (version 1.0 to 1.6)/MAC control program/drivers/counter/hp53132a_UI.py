from tasks.datalog import *
from driver.counter.hp53132a import HP53132A

class DataLogger(object):

	def __init__(self,counter):
		self.counter = counter
		# self.consThread = None
		# self.asservConsThread = None
		# self.running = False

	def __del__(self):
		self.stop()

	def start(self):
		assert not self.running
		self.running = True

		timeStr = time.strftime("%Y-%m-%d %H%M")
		self.f1 = open("{}\datalog {} A.txt".format(data_folder_path,timeStr),'w')

		# Init producer thread
		# aux_columns = [["Time",time.time],
						# ["Cell resistor (kohm)",(a.tempCtrl,'resistance')],
						# ["Cell heat voltage (V)",(a.tempCtrl,'voltage')]]
		
		# aux_headers = [item[0] for item in aux_columns]
		# aux_getters = [item[1] for item in aux_columns]
		# self.prodThread = DataProducer(aux_headers, aux_getters)

		# Init and start consumer threads
		# self.consThread = DataConsumer(self.f1,self.prodThread.header)
		self.asservConsThread = DataConsumer(self.f1,self.header)
		# self.consThread.start()
		self.asservConsThread.start()

		# Start producer threads
		# self.prodThread.start()
		self.counter.queue = self.asservConsThread.data.queue
		self.prodThread.queue = self.consThread.data.queue

	def stop(self):
		if self.running:
			self.running = False
			# self.consThread.stop()
			self.asservConsThread.stop()
			# self.prodThread.stop()
			a.asserv.dataQueue = None
			self.f1.close()
			# self.f2.close()

	def empty(self):
		# self.consThread.empty()
		self.asservConsThread.empty()
			


class HP53132A_UI(HP53132A):

	def __init__(self,*args,**kargs):
		super(HP53132A_UI, self).__init__(*args,**kargs)


if __name__=='__main__':
	counter = HP53132A_UI()
	dl = DataLogger(counter)