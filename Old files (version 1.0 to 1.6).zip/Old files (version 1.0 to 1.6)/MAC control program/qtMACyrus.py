import sys, time
from math import log
#from collections import deque
from mac_drivercyrus import MAC
from utils.misc import Buffer
from serial.tools import list_ports
#import numpy as np

print "Loading pyqtgraph",
import pyqtgraph as pg
from pyqtgraph.dockarea import *
from pyqtgraph.Qt import QtGui, QtCore
import pyqtgraph.parametertree.parameterTypes as pTypes
from ui.pyqtgraphaddon import MyFloatParameter
from pyqtgraph.parametertree import Parameter, ParameterTree
print " [DONE]"

class DeviceSet(object):
	def __init__(s):

		print "Is well Connecting to devices",
		s.mac = MAC()
		print " [Donating money cash please]"

class SerialReader(pg.QtCore.QThread):

	# new_current_value = pg.QtCore.Signal()
	current_buffer = Buffer(10000)
	quartzword_buffer = Buffer(10000)
	error_sig_buffer = Buffer(10000)

	def __init__(self):
		super(SerialReader, self).__init__()
		self.running = False

	def run(self):
		self.running = True
		while self.running:
			# try:
			line = a.mac.ser.readline()
			if line:
				if line[0] == 'D': print line[2:-2]
				elif line[0] == 'I':
					self.current_buffer.append(time.time(),int(line[2:-2]))
				elif line[0] == 'Q':
					self.quartzword_buffer.append(time.time(),int(line[2:-2]))
				elif line[0] == 'E':
					dacw_error_array = line[2:-2].split(' ')
					self.error_sig_buffer.append(int(dacw_error_array[0]),float(dacw_error_array[1]))
					# self.new_current_value.emit()
			# except:
			# 	print "Something is wrong..."
			# time.sleep(0.)

class SerialConsole(pg.LayoutWidget):
	def __init__(s, window=None):
		super(SerialConsole, s).__init__()
		s.command_box = QtGui.QLineEdit(s)
		s.send_button = QtGui.QPushButton('Send')
		s.addWidget(s.command_box,row=0, col=0)
		s.addWidget(s.send_button,row=0, col=1)

		s.send_button.clicked.connect(s.send_command)

	def send_command(s):
		command = s.command_box.text()
		a.mac.ser.write(str(command))
		s.command_box.setText("")

class ControlWidget(pg.LayoutWidget):
    def __init__(s, window=None):
		super(ControlWidget, s).__init__(window)
		s.window = window

		s.p = Parameter.create(name='params', type='group')
		
		s.startup = Parameter.create(name='Start Up', type='action')
		s.p.addChild(s.startup)
		
		gp0 = pTypes.GroupParameter(name='ADF4158 (Frequency Synthesis)')
		s.set_all_regesiters = Parameter.create(name='Set registers', type='action')
		s.set_frequency = MyFloatParameter.create(name='Frequency', type='float2', value=a.mac.adf.frequency, step = 1000, suffix='Hz')
		s.ramp_on = Parameter.create(name='Ramp', type='bool', value=a.mac.adf.ramp_on)
		s.set_deviation = Parameter.create(name='Ramp deviation', type='float', value=a.mac.adf.total_freq_ramp, step = 1000, suffix='Hz')
		s.clock2 = Parameter.create(name='Clock2 divider', type='int', value=a.mac.adf.clk2_divider_value, step = 1)
		s.ramp_steps = Parameter.create(name='Ramp steps', type='int', value=a.mac.adf.ramp_steps, step = 1)				
		readonlygroup = pTypes.GroupParameter(name='Current values')
		s.act_frequency = MyFloatParameter.create(name='Frequency', type='float2', value=a.mac.adf.frequency, readonly=True, suffix='Hz',enabled = False)
		s.act_deviation = Parameter.create(name='Ramp deviation', type='float', value=a.mac.adf.total_freq_ramp, readonly=True, suffix='Hz')
		s.ramp_time = MyFloatParameter.create(name='Total ramp time', type='float2', value=a.mac.adf.total_time_ramp, readonly=True, suffix='s')
		readonlygroup.addChildren([s.act_frequency,s.act_deviation,s.ramp_time])
		gp0.addChildren([s.set_all_regesiters,s.set_frequency,s.ramp_on,s.set_deviation,s.clock2,s.ramp_steps,readonlygroup])
		s.p.addChild(gp0)

		gp1 = pTypes.GroupParameter(name='Laser control')
		s.laser_startup = Parameter.create(name='Startup', type='action')
		s.laser_current = Parameter.create(name='Current', type='float', value=a.mac.lascursour.current, step = 0.001, suffix='mA')
		s.tec_state = Parameter.create(name="TEC state", type="bool",value=a.mac.lastecctrl.tec_state)
		s.tec_volt_word = Parameter.create(name="TEC word", type="int", value=a.mac.lastecctrl.tec_volt_word, step = 1)
		s.tec_resistance = Parameter.create(name="TEC resistance", type="float", value=a.mac.lastecctrl.tec_resistance, step = 100, suffix="ohm")
		gp1.addChildren([s.laser_startup,s.laser_current,s.tec_state,s.tec_volt_word,s.tec_resistance])
		s.p.addChild(gp1)

		gp2 = pTypes.GroupParameter(name='Magnetic field current source')
		s.mag_current = Parameter.create(name='Current', type='float', value=a.mac.magcursour.current, step = 0.1, suffix='mA')
		gp2.addChildren([s.mag_current])
		s.p.addChild(gp2)

		s.lockon = Parameter.create(name='Laser lock ON', type='action')
		s.p.addChild(s.lockon)

		gp3 = pTypes.GroupParameter(name='Scope')
		s.scope_state = Parameter.create(name='Acquisition', type='bool', value=False)
		s.clear_error_sig_action = Parameter.create(name='Clear', type='action')
		gp3.addChildren([s.scope_state,s.clear_error_sig_action])
		s.p.addChild(gp3)

		t = ParameterTree()
		t.setParameters(s.p, showTop=False)
		s.addWidget(t,row=0, col=0)

		s.p.sigTreeStateChanged.connect(s.change)

		s.startup.sigActivated.connect(a.mac.startup)
		s.lockon.sigActivated.connect(a.mac.lock)
		s.set_all_regesiters.sigActivated.connect(a.mac.adf.send_all_reg)
		s.laser_startup.sigActivated.connect(a.mac.lascursour.startup)

		def clear_error_sig_plot():
			serial_reader.error_sig_buffer.clear()

		s.clear_error_sig_action.sigActivated.connect(clear_error_sig_plot)
        
    def change(s,param,changes):
		for param, change, data in changes:
			if param is s.set_frequency:
				a.mac.adf.frequency = param.value()
				s.act_frequency.setValue(a.mac.adf.frequency)
			elif param is s.ramp_on: a.mac.adf.ramp_on = param.value()
			elif param is s.set_deviation:
				a.mac.adf.total_freq_ramp = param.value()
				s.act_deviation.setValue(a.mac.adf.total_freq_ramp)
			elif param is s.clock2:
				a.mac.adf.clk2_divider_value = param.value()
				s.ramp_time.setValue(a.mac.adf.total_time_ramp)
			elif param is s.ramp_steps:
				a.mac.adf.ramp_steps = param.value()
				s.ramp_time.setValue(a.mac.adf.total_time_ramp)
				s.act_deviation.setValue(a.mac.adf.total_freq_ramp)
			elif param is s.laser_current: a.mac.lascursour.current = param.value()
			elif param is s.tec_state: a.mac.lastecctrl.tec_state = param.value()
			elif param is s.tec_volt_word: a.mac.lastecctrl.tec_volt_word = param.value()
			elif param is s.tec_resistance: a.mac.lastecctrl.tec_resistance = param.value()
			elif param is s.mag_current: a.mac.magcursour.current = param.value()
			elif param is s.scope_state:
				if param.value():
					s.window.live_graph_widget.start_timer()
					a.rp_scope.start()
				else: 
					s.window.live_graph_widget.stop_timer()
					a.rp_scope.stop()


class LiveGraphWidget(pg.GraphicsLayoutWidget):
	def __init__(self, window=None):
		super(LiveGraphWidget, self).__init__(window)
		self.p1 = self.addPlot()
		self.p1.showGrid(x=False, y=True, alpha=0.8)
		self.curve1 = self.p1.plot(pen=pg.mkPen((0, 255, 155,255)))
		self.nextRow()
		self.p2 = self.addPlot()
		self.p2.showGrid(x=False, y=True, alpha=0.8)
		self.curve2 = self.p2.plot(pen=pg.mkPen((0, 155, 255,255)))
		self.timer = QtCore.QTimer()
		self.timer.timeout.connect(self.update)
		self.start_timer()

	def update(self):
		if serial_reader:
			self.curve1.setData(y=serial_reader.current_buffer.get_data())
			self.curve2.setData(y=serial_reader.quartzword_buffer.get_data())

	def start_timer(self):
		self.timer.start(100)

	def stop_timer(self):
		self.timer.stop()

class ErrorGraphWidget(pg.GraphicsLayoutWidget):
	def __init__(self, window=None):
		super(ErrorGraphWidget, self).__init__(window)
		self.p1 = self.addPlot()
		self.p1.showGrid(x=True, y=True, alpha=0.8)
		self.curve1 = self.p1.plot(pen=pg.mkPen((0, 255, 155,255)))
		self.timer = QtCore.QTimer()
		self.timer.timeout.connect(self.update)
		self.start_timer()

	def update(self):
		if serial_reader:
			y = serial_reader.error_sig_buffer.get_data()
			x = serial_reader.error_sig_buffer.get_times()
			n = min(len(x),len(y))
			if n>1:
				self.curve1.setData(x=x[0:n],y=y[0:n])

	def start_timer(self):
		self.timer.start(100)

	def stop_timer(self):
		self.timer.stop()

class MyWindow(QtGui.QMainWindow):
	def __init__(self):
		QtGui.QMainWindow.__init__(self)
		self.setWindowTitle("qtMain")
		self.resize(1400,900)

		self.control_widget = ControlWidget(self)
		self.live_graph_widget = LiveGraphWidget(self)
		self.serial_console = SerialConsole(self)
		self.error_sig_widget = ErrorGraphWidget(self)

		area = DockArea()
		self.setCentralWidget(area)

		d1 = Dock("Controls", size=(400, 1))
		d2 = Dock("Time plots", size=(1000, 1))
		d3 = Dock("Console", size=(1, 1))
		d4 = Dock("Error signal", size=(1000, 1))
		
		area.addDock(d3, 'top')
		area.addDock(d1, 'bottom')
		area.addDock(d2, 'right',d1)
		area.addDock(d4, 'bottom',d2)

		d1.addWidget(self.control_widget)
		d2.addWidget(self.live_graph_widget)
		d3.addWidget(self.serial_console)
		d4.addWidget(self.error_sig_widget)

	def keyPressEvent(self, event):
		if event.key() == QtCore.Qt.Key_Enter or event.key() == QtCore.Qt.Key_Return :
			self.serial_console.send_command()

a = DeviceSet()
serial_reader = None
app = QtGui.QApplication([])
win = MyWindow()
win.show()
serial_reader = SerialReader()
serial_reader.start()

# serial_reader.new_current_value.connect(test)

if __name__ == "__main__":
	if (sys.flags.interactive != 1) or not hasattr(QtCore, 'PYQT_VERSION'):
		ret = QtGui.QApplication.instance().exec_()
		sys.exit(ret)