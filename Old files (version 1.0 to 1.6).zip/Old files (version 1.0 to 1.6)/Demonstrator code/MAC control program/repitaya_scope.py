#!/usr/bin/python
import threading
import redpitaya_scpi as scpi
from collections import deque
import numpy as np

class RedpitayaScope(threading.Thread):

	mean = 8
	_numSamp = 16384

	def __init__(self,ip="192.168.1.100"):
		self.rp_s = scpi.scpi(ip)
		self.data = np.zeros((self.mean,self._numSamp),dtype=np.float64)
		self.deque = deque([],self.mean)
		self.ptr = 0
		self.running = False

	def run(self):
		self.running = True
		while running:
			rp_s.tx_txt('ACQ:START')
			rp_s.tx_txt('ACQ:TRIG NOW')

			while 1:
				rp_s.tx_txt('ACQ:TRIG:STAT?')
				if rp_s.rx_txt() == 'TD':
					break

			rp_s.tx_txt('ACQ:SOUR1:DATA?')
			buff_string = rp_s.rx_txt()
			buff_string = buff_string.strip('{}\n\r').replace("  ", "").split(',')
			self.data[self.ptr] = map(float, buff_string)
			self.deque.append(self.ptr)
			self.mean=np.mean(self.data[self.deque],axis=0)
			self.ptr=(self.ptr+1)%self.mean
			print ptr

if __name__ == "__main__":
	rp_scope = RedpitayaScope()