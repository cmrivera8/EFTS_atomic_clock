  # ADF4158_Write(0x7) R7
  # ADF4158_Write(0x800006) R6_2
  # ADF4158_Write(0x3E86) R6_1
  # ADF4158_Write(0x800005) R5_2
  # ADF4158_Write(0x1002A5) R5_1
  # ADF4158_Write(0x783204) R4
  # ADF4158_Write(0x43) R3
  # ADF4158_Write(0x40800A) R2
  # ADF4158_Write(0x1280001) R1
  # ADF4158_Write(0xF8E5D0A8) R0

def split(number,lsb_pos,bit_num):
  return (number>>lsb_pos) & 2**bit_num-1

def split_R0(n):
  return [split(n,31,1), split(n,27,4), split(n,15,12), split(n,3,12)]

def split_R1(n):
  return [split(n,15,13)]

def split_R2(n):
  return [split(n,28,1), split(n,24,4), split(n,22,1), split(n,21,1), split(n,20,1), split(n,15,5), split(n,3,12)]

def split_R3(n):
  return [split(n,15,1), split(n,14,1), split(n,10,2), split(n,9,1), split(n,8,1), split(n,7,1), split(n,6,1), split(n,5,1), split(n,4,1), split(n,3,1)]

def split_R4(n):
  return [split(n,31,1), split(n,26,5), split(n,23,2), split(n,21,2), split(n,19,2), split(n,7,12)]

def split_R5(n):
  return [split(n,29,1), split(n,28,1), split(n,26,2), split(n,25,1), split(n,24,1), split(n,23,1), split(n,19,4), split(n,3,16)]

def split_R6(n):
  return [split(n,23,1), split(n,3,20)]

def split_R7(n):
  return [split(n,18,1),split(n,17,1),split(n,16,1),split(n,15,1),split(n,3,12)]

class ADF4158(object):
  _READBACK_TO_MUXOUT = 0b1111
  
  _ref_in_freq = 10e6 # Reference In frequency
  #R0
  _ramp_on = 1 # 1 bit
  _mux_out_control = _READBACK_TO_MUXOUT # 4 bits
  _interger_value = 459  # 12 bits
  _msb_frac_value = 2581 # 12 bits
  #R1
  _lsb_frac_value = 592  # 13 bits (DBB)
  #R2
  _csr_en = 0            # 1 bit
  _cp_current_set = 0    # 4 bits  0 = 0.3125 mA
  _prescaler = 1         # 1 bit (1 = 8/9)
  _rdiv2 = 0             # 1 bit (R Divider)
  _reference_doubler = 0 # 1 bit (reference doubler)
  _r_counter = 1         # 5 bit (r-counter divide ratio)
  _clk1_divider = 1      # 12 bits (Clk1 divider value)
  #R3
  _n_sel = 0
  _sd_reset = 0
  _ramp_mode = 0
  _psk_enable = 0
  _fsk_enable = 0
  _ldp = 0
  _pd_polarity = 1
  _power_down = 0
  _cp_three_state = 0
  _counter_reset = 0
  #R4
  _le_sel = 0
  _sigma_delta_modulator_mode = 0
  _neg_bleed_current = 0
  _readback_muxout = 3
  _clk_div_mode = 3
  _clk2_divider_value = 100
  #R5
  _tx_ramp_clk = 0
  _par_ramp = 0      # Parabolic ramp
  _interrupt = 0
  _fsk_ramp_en = 0
  _ramp_2_en = 0
  _up_dev_sel = 0 # RAMP1
  _up_dev_offset_word = 2 # Up ramp DEVoff
  _up_deviation_word = 84 # Up ramp DEV
  _down_dev_sel = 1 # RAMP2
  _down_dev_offset_word = 0 # Down ramp DEVoff
  _down_deviation_word = 0 # Down ramp DEV
  #R6
  _up_step_word = 2000
  _down_step_word = 0
  #R7
  _ramp_del_fl = 0
  _ramp_del = 0
  _del_clk_sel = 0
  _del_start_en = 0

  def R0(s):
    return (s._ramp_on<<31) + (s._mux_out_control<<27) + (s._interger_value<<15) + (s._msb_frac_value<<3)+0

  def R1(s):
    return (s._lsb_frac_value<<15)+1

  def R2(s):
    return (s._csr_en<<28)+(s._cp_current_set<<24)+(s._prescaler<<22)+(s._rdiv2<<21)+(s._reference_doubler<<20)+(s._r_counter<<15)+(s._clk1_divider<<3)+2

  def R3(s):
    return (s._n_sel<<15)+(s._sd_reset<<14)+(s._ramp_mode<<10)+(s._psk_enable<<9)+(s._fsk_enable<<8)+(s._ldp<<7)+(s._pd_polarity<<6)+(s._power_down<<5)+(s._cp_three_state<<4)+(s._counter_reset<<7)+3

  def R4(s):
    return (s._le_sel<<31)+(s._sigma_delta_modulator_mode<<26)+(s._neg_bleed_current<<23)+(s._readback_muxout<<21)+(s._clk_div_mode<<19)+(s._clk2_divider_value<<7)+4

  def R5_1(s):
    return (s._tx_ramp_clk<<29)+(s._par_ramp<<28)+(s._interrupt<<26)+(s._fsk_ramp_en<<25)+(s._ramp_2_en<<24)+(s._up_dev_sel<<23)+(s._up_dev_offset_word<<19)+(s._up_deviation_word<<3)+5

  def R5_2(s):
    return (s._tx_ramp_clk<<29)+(s._par_ramp<<28)+(s._interrupt<<26)+(s._fsk_ramp_en<<25)+(s._ramp_2_en<<24)+(s._down_dev_sel<<23)+(s._down_dev_offset_word<<19)+(s._down_deviation_word<<3)+5

  def R6_1(s):
    return (s._up_dev_sel<<23)+(s._up_step_word<<3)+6

  def R6_2(s):
    return (s._down_dev_sel<<23)+(s._down_step_word<<3)+6

  def R7(s):
    return (s._ramp_del_fl<<18)+(s._ramp_del<<17)+(s._del_clk_sel<<16)+(s._del_start_en<<15)+7

  @property
  def ref_in_freq(self):
      return self._ref_in_freq

  @property
  def _freq_pfd(s):
    return s._ref_in_freq*( (1 + s._reference_doubler) / float(s._r_counter*(1+s._rdiv2)) )

  @property
  def _frac_value(s):
    return ((s._msb_frac_value << 13) + s._lsb_frac_value)/float(2**25)

  @property
  def frequency(s):
    return (s._frac_value + s._interger_value)*s._freq_pfd

  @property
  def freq_dev(s):
    """Frequency deviation per step ()"""
    return s._freq_pfd/(2**25)*float(s._up_deviation_word)*(2**float(s._up_dev_offset_word))

  @property
  def total_freq_ramp(s):
    return s.freq_dev * s._up_step_word

  @property
  def time_per_step(s):
    """Time between each step"""
    return s._clk1_divider * s._clk2_divider_value / float(s._freq_pfd)

  @property
  def total_time_ramp(s):
    return s.time_per_step * s._up_step_word

  @property
  def chan_spacing(s):
    return 1/float(2**25)*s._freq_pfd

  def preview_all_registers(s):
    print hex(s.R0())
    print hex(s.R1())
    print hex(s.R2())
    print hex(s.R3())
    print hex(s.R4())
    print hex(s.R5_1())
    print hex(s.R5_2())
    print hex(s.R6_1())
    print hex(s.R6_2())
    print hex(s.R7())

adf = ADF4158()