import sys

from mac_driver import MAC
from repitaya_acquire import RedpitayaScope
import numpy as np

print "Loading pyqtgraph",
import pyqtgraph as pg
from pyqtgraph.dockarea import *
from pyqtgraph.Qt import QtGui, QtCore
import pyqtgraph.parametertree.parameterTypes as pTypes
from ui.pyqtgraphaddon import MyFloatParameter
from pyqtgraph.parametertree import Parameter, ParameterTree
print " [DONE]"

class DeviceSet(object):
	def __init__(s):
		#Setup equipments
		print "Connecting to devices",
		s.mac = MAC(comPort='com4')
		#s.rp_scope = RedpitayaScope()
		print " [DONE]"


class ControlWidget(pg.LayoutWidget):
	def __init__(s, window=None):
		super(ControlWidget, s).__init__(window)
		s.window = window

		s.p = Parameter.create(name='params', type='group')
		
		s.startup = Parameter.create(name='Start Up', type='action')
		s.p.addChild(s.startup)
		
		gp0 = pTypes.GroupParameter(name='ADF4158 (Frequency Synthesis)')
		s.set_all_regesiters = Parameter.create(name='Set registers', type='action')
		s.set_frequency = MyFloatParameter.create(name='Frequency', type='float2', value=a.mac.adf.frequency, step = 1000, suffix='Hz')
		s.ramp_on = Parameter.create(name='Ramp', type='bool', value=a.mac.adf.ramp_on)
		s.set_deviation = Parameter.create(name='Ramp deviation', type='float', value=a.mac.adf.total_freq_ramp, step = 1000, suffix='Hz')
		s.clock2 = Parameter.create(name='Clock2 divider', type='int', value=a.mac.adf.clk2_divider_value, step = 1)
		s.ramp_steps = Parameter.create(name='Ramp steps', type='int', value=a.mac.adf.ramp_steps, step = 1)				
		readonlygroup = pTypes.GroupParameter(name='Current values')
		s.act_frequency = MyFloatParameter.create(name='Frequency', type='float2', value=a.mac.adf.frequency, readonly=True, suffix='Hz',enabled = False)
		s.act_deviation = Parameter.create(name='Ramp deviation', type='float', value=a.mac.adf.total_freq_ramp, readonly=True, suffix='Hz')
		s.ramp_time = MyFloatParameter.create(name='Total ramp time', type='float2', value=a.mac.adf.total_time_ramp, readonly=True, suffix='s')
		readonlygroup.addChildren([s.act_frequency,s.act_deviation,s.ramp_time])
		gp0.addChildren([s.set_all_regesiters,s.set_frequency,s.ramp_on,s.set_deviation,s.clock2,s.ramp_steps,readonlygroup])
		s.p.addChild(gp0)

		gp1 = pTypes.GroupParameter(name='Laser control')
		s.laser_startup = Parameter.create(name='Startup', type='action')
		s.laser_current = Parameter.create(name='Current', type='float', value=a.mac.lascursour.current, step = 0.0001, suffix='mA')
		s.tec_state = Parameter.create(name="TEC state", type="bool",value=a.mac.lastecctrl.tec_state)
		s.tec_volt_word = Parameter.create(name="TEC word", type="int", value=a.mac.lastecctrl.tec_volt_word, step = 1)
		s.tec_resistance = Parameter.create(name="TEC resistance", type="float", value=a.mac.lastecctrl.tec_resistance, step = 100, suffix="ohm")
		gp1.addChildren([s.laser_startup,s.laser_current,s.tec_state,s.tec_volt_word,s.tec_resistance])
		s.p.addChild(gp1)

		gp2 = pTypes.GroupParameter(name='Magnetic field current source')
		s.mag_current = Parameter.create(name='Current', type='float', value=a.mac.magcursour.current, step = 0.1, suffix='mA')
		gp2.addChildren([s.mag_current])
		s.p.addChild(gp2)

		s.lockon = Parameter.create(name='Laser lock ON', type='action')
		s.p.addChild(s.lockon)

		gp3 = pTypes.GroupParameter(name='Scope')
		s.scope_state = Parameter.create(name='Acquisition', type='bool', value=False)
		gp3.addChildren([s.scope_state])
		s.p.addChild(gp3)

		t = ParameterTree()
		t.setParameters(s.p, showTop=False)
		s.addWidget(t,row=0, col=0)

		s.p.sigTreeStateChanged.connect(s.change)

		s.startup.sigActivated.connect(a.mac.startup)
		s.lockon.sigActivated.connect(a.mac.lock)
		s.set_all_regesiters.sigActivated.connect(a.mac.adf.send_all_reg)
		s.laser_startup.sigActivated.connect(a.mac.lascursour.startup)

	def change(s,param,changes):
		for param, change, data in changes:
			if param is s.set_frequency:
				a.mac.adf.frequency = param.value()
				s.act_frequency.setValue(a.mac.adf.frequency)
			elif param is s.ramp_on: a.mac.adf.ramp_on = param.value()
			elif param is s.set_deviation:
				a.mac.adf.total_freq_ramp = param.value()
				s.act_deviation.setValue(a.mac.adf.total_freq_ramp)
			elif param is s.clock2:
				a.mac.adf.clk2_divider_value = param.value()
				s.ramp_time.setValue(a.mac.adf.total_time_ramp)
			elif param is s.ramp_steps:
				a.mac.adf.ramp_steps = param.value()
				s.ramp_time.setValue(a.mac.adf.total_time_ramp)
				s.act_deviation.setValue(a.mac.adf.total_freq_ramp)
			elif param is s.laser_current: a.mac.lascursour.current = param.value()
			elif param is s.tec_state: a.mac.lastecctrl.tec_state = param.value()
			elif param is s.tec_volt_word: a.mac.lastecctrl.tec_volt_word = param.value()
			elif param is s.tec_resistance: a.mac.lastecctrl.tec_resistance = param.value()
			elif param is s.mag_current: a.mac.magcursour.current = param.value()
			elif param is s.scope_state:
				if param.value():
					s.window.live_graph_widget.start_timer()
					a.rp_scope.start()
				else: 
					s.window.live_graph_widget.stop_timer()
					a.rp_scope.stop()


class LiveGraphWidget(pg.GraphicsLayoutWidget):
	def __init__(self, window=None):
		super(LiveGraphWidget, self).__init__(window)
		labelStyle = {'color': '#FFF', 'size': '10pt'}
		self.meas_lbl = self.addLabel("Measurements",**labelStyle)
		self.nextRow()
		self.p = self.addPlot()
		self.p.showGrid(x=True, y=True, alpha=0.8)
		self.curve = self.p.plot(pen=pg.mkPen((0, 255, 155,30)))
		self.meanCurve = self.p.plot(pen=pg.mkPen((0, 255, 255,255)))
		# self.fitCurve = self.p.plot(pen="r")
		self.timer = QtCore.QTimer()
		self.timer.timeout.connect(self.update)
		self.fm_dev = None
		self.p.setLabel('left', "Signal", units='V')
		self.p.setLabel('bottom', "Frequency deviation")

	def update(self):

		y_data = a.rp_scope.last_data_array
		y_mean = a.rp_scope.mean_array
		# if self.fm_dev:
		# 	x = x*self.fm_dev
		background = np.min(y_mean)
		signal = np.max(y_mean)-background
		contrast = signal/background
		self.meas_lbl.setText("Signal: {:.4f} mV    Background: {:.4f} mV  Contrast: {:.2f} %".format(signal*1000,background*1000,contrast*100))
		self.curve.setData(y=y_data)
		self.meanCurve.setData(y=y_mean)
		# if a.rp_scope.ptr != 0:
		# 	self.p.enableAutoRange('xy', False)

	# def update_label(self):
	# 	# self.frequency = a.fs.frequency
	# 	self.p.setLabel('bottom', "Frequency shift from {:.2f}".format(self.frequency), units='Hz')

	def start_timer(self):
		# self.fm_dev = a.fs.fm_dev
		# self.update_label()
		self.timer.start(100)

	def stop_timer(self):
		self.timer.stop()

	# def fit(self):
	# 	x, y = a.syncAiAo.getNthChanAImean(0)
	# 	if self.fm_dev:
	# 		x = x*self.fm_dev
	# 	self.fitter = Fitter(x,y)
	# 	self.fitter.newData.connect(self.update_fit_curve)
	# 	self.fitter.start()

	# def update_fit_curve(self,x,fitData):
	# 	self.fitCurve.setData(x=x,y=fitData)


class MyWindow(QtGui.QMainWindow):
	def __init__(self):
		QtGui.QMainWindow.__init__(self)
		self.setWindowTitle("qtMain")
		self.resize(1400,900)

		self.control_widget = ControlWidget(self)
		self.live_graph_widget = LiveGraphWidget(self)

		area = DockArea()
		self.setCentralWidget(area)

		d1 = Dock("Controls", size=(400, 1))
		d2 = Dock("CPT signal", size=(1000, 1))
		
		area.addDock(d1, 'left')
		area.addDock(d2, 'right')

		d1.addWidget(self.control_widget)
		d2.addWidget(self.live_graph_widget)

a = DeviceSet()

app = QtGui.QApplication([])
win = MyWindow()
win.show()

if __name__ == "__main__":
	if (sys.flags.interactive != 1) or not hasattr(QtCore, 'PYQT_VERSION'):
		ret = QtGui.QApplication.instance().exec_()
		sys.exit(ret)