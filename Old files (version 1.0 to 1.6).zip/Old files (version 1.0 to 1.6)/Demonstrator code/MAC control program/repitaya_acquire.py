#!/usr/bin/python
import threading
import redpitaya_scpi as scpi
from collections import deque
import numpy as np

TRIG_MODES = ["DISABLED","NOW","CH1_PE","CH2_PE","CH1_NE","CH2_NE"]

class RedpitayaScope(object):

	mean = 16
	_numSamp = 16384
	default_trig_mode = "CH2_PE" #"NOW"

	def __init__(self,ip="192.168.1.100"):
		self.rp_s = scpi.scpi(ip)
		self.running = False
		self.initialize()

	def initialize(self):
		self.set_gain(1,"HV")
		self.set_gain(2,"LV")
		self.trigger_level = 0.9
		self.data_array = np.zeros((self.mean,self._numSamp),dtype=np.float64)
		self.mean_array = np.zeros(self._numSamp,dtype=np.float64)
		self.deque = deque([],self.mean)
		self.ptr = 0

	@property
	def decimation_factor(self):
		self.rp_s.tx_txt('ACQ:DEC?')
		return int(self.rp_s.rx_txt())

	@decimation_factor.setter
	def decimation_factor(self,factor):
		self.rp_s.tx_txt('ACQ:DEC '+str(int(factor)))

	@property
	def averaging(self):
		self.rp_s.tx_txt('ACQ:AVG?')
		return "ON" in self.rp_s.rx_txt()

	@averaging.setter
	def averaging(self,state):
		dic = {0:"OFF",1:"ON"}
		self.rp_s.tx_txt('ACQ:AVG '+dic[state])

	@property
	def trigger_level(self):
		self.rp_s.tx_txt('ACQ:TRIG:LEV?')
		return float(self.rp_s.rx_txt())

	@trigger_level.setter
	def trigger_level(self,level):
		self.rp_s.tx_txt('ACQ:TRIG:LEV '+str(level))

	@property
	def buffer_size(self):
		self.rp_s.tx_txt('ACQ:BUF:SIZE?')
		return int(self.rp_s.rx_txt())
	
	def set_gain(self,source,gain="HV"):
		assert gain in ("LV","HV")
		assert source in (1,2)
		self.rp_s.tx_txt("ACQ:SOUR"+str(source)+"GAIN "+gain)

	def set_trigger_mode(self,mode):
		assert mode in TRIG_MODES
		self.rp_s.tx_txt("ACQ:TRIG "+mode)

	@property
	def last_data_array(self):
		if len(self.deque)>0:
			return self.data_array[self.deque[-1]]
		return None

	# @property
	# def sampling_rate(self):
	# 	self.rp_s.tx_txt('ACQ:SRA:HZ?')
	# 	return self.rp_s.rx_txt()

	def start(self):
		self.initialize()
		def run():
			self.running = True
			print "Starting acquisition"
			while self.running:
				self.rp_s.tx_txt('ACQ:START')
				self.set_trigger_mode(self.default_trig_mode)
				while self.running:
					self.rp_s.tx_txt('ACQ:TRIG:STAT?')
					if self.rp_s.rx_txt() == 'TD':
						break

				self.rp_s.tx_txt('ACQ:SOUR1:DATA?')
				buff_string = self.rp_s.rx_txt()
				buff_string = buff_string.strip('{}\n\r').replace("  ", "").split(',')
				self.data_array[self.ptr] = map(float, buff_string)
				self.deque.append(self.ptr)
				self.mean_array=np.mean(self.data_array[self.deque],axis=0)
				self.ptr=(self.ptr+1)%self.mean
				# print self.ptr
			print "Acquisition stopped"

		self.thread = threading.Thread(target=run)
		self.thread.daemon = True
		print "Starting thread"
		self.thread.start()

	def stop(self):
		self.running = False
		self.thread.join()
		print "Thread stopped"

if __name__ == "__main__":
	rp_scope = RedpitayaScope()